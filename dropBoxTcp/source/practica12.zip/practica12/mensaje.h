#define TAM_MAX_DATA 4000
//Optimizacion:
//#define TAM_MAX_DATA 8

#define suma 1

struct mensaje{
	int messageType;
	unsigned int requestId;
	int operationId;
	char arguments[TAM_MAX_DATA];
};