#include"Solicitud.h"
#include<iostream>
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
using namespace std;
int main(){
	 

	char ip[]="25.39.197.181";
	int puerto=7200,*nbd,cont=0;

	int dep;
	printf("Ingresa numero de depositos: ");
	scanf("%d",&dep);

	Solicitud s1;

	for(int i=0;i<dep;i++){
		int r= rand() % 9 + 1;  
		cont+=r;
		printf("rand: %d\n",r);
		nbd=(int*)s1.doOperation(ip,puerto,suma,(char*)&r);
		if(cont!=nbd[0]){
			printf("Los montos no coinciden\n");
			exit(0);
		}
	}
	printf("Cont: %d\n",cont);

	
}