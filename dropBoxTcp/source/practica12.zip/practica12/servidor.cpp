#include"Respuesta.h"
#include<stdio.h>
#include<iostream>
#include<string.h>
#include<stdlib.h>
using namespace std;
int main(){
		
	//Puerto para la llegada de solicitudes
	int puerto,nbd=0;
	printf("Ingrese el puerto para solicitudes: ");
	scanf("%d",&puerto);
	Respuesta r(puerto);

	while(true){
		mensaje *msg;
		msg=r.getRequest();

		if(msg){
			switch(msg->operationId){
				case suma:
					int res[1],ans;
					memcpy(res,msg->arguments,4);
					nbd+=res[0];
					msg->messageType=1;
					memcpy(msg->arguments,&nbd,TAM_MAX_DATA+12);
					r.sendReply((char*)msg);
					printf("pbd: %d\n",nbd);
					break;
				default:
				break;
			}
		}
	}

}