#include"Solicitud.h"
#include<stdio.h>
#include<string.h>

Solicitud::Solicitud(){
	socketlocal = new SocketDatagrama(0);
	reqstId=0;
}

char* Solicitud::doOperation(char *IP, int puerto, int operationId, char *arguments){

	mensaje msg, *ptr1,*ptr2;
	msg.messageType = 0;
	msg.requestId=reqstId;
	msg.operationId=operationId;
	memcpy(msg.arguments,arguments,TAM_MAX_DATA);
	
	ptr1=&msg;

	PaqueteDatagrama pdreqs((char*)ptr1,sizeof(msg),IP,puerto),pdresp(sizeof(msg));
	
	int sal = 0, cont =0;
	//El ciclo do-while garantiza que se envie por lo menos una vez el paquete
	do{

		//El reqstId no se incrementa dentro de este ciclo dado que es el mismo mensaje 

		//Si se logra enviar el mensaje se incrementa el identificador de mensaje (requestId)
		if((socketlocal->envia(pdreqs))>=0)
			cont++;

		// Si no es igual a -1 (quiere decir que recibío respuesta del servidor), sale del ciclo
		if((socketlocal->recibeTimeout(pdresp, 2, 500000)) >= 0){ 
			sal = 1;
			break;
		}
	}while(cont < 7); // <7 porque se tiene que tartar de enviar 7 veces si se agota el tiempo
	
	/*Al termino del ciclo do-while se tiene la seguridad de que se logro enviar
	el mensaje (independientemente de si hubo respuesta o no), con lo cual se puede incrementar reqstId*/
	reqstId++;

	if(sal == 0) printf("El servidor no esta disponible\n");


	//IP y puerto del servidor
	//printf("%s\n",pdresp.obtieneDireccion());
	//printf("%d\n",pdresp.obtienePuerto());

	ptr2=(mensaje*)pdresp.obtieneDatos();

	return ptr2->arguments;
}