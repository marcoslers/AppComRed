#include"Respuesta.h"
#include<stdio.h>
#include<string.h>
Respuesta::Respuesta(int pl){
	socketlocal = new SocketDatagrama(pl);
	paqueteDat = new PaqueteDatagrama(TAM_MAX_DATA+12);
	idreqstc=0;
}

struct mensaje* Respuesta::getRequest(void){

	PaqueteDatagrama pdreqst(TAM_MAX_DATA+12);


	socketlocal->recibe(pdreqst);


	paqueteDat->inicializaIp(pdreqst.obtieneDireccion());
	paqueteDat->inicializaPuerto(pdreqst.obtienePuerto());	
	
	printf("%s\n",pdreqst.obtieneDireccion());
	printf("%d\n",pdreqst.obtienePuerto());

	mensaje *msg;

	msg=(mensaje*)pdreqst.obtieneDatos();

	if(idreqstc==(msg->requestId)){
		idreqstc++;
		return (mensaje*)pdreqst.obtieneDatos();
	}else return NULL; //Al retornar null significa que el mensaje recibido esta repetido

}
void Respuesta::sendReply(char *respuesta){
	PaqueteDatagrama pdresp(respuesta,TAM_MAX_DATA+12,paqueteDat->obtieneDireccion(),paqueteDat->obtienePuerto());
	socketlocal->envia(pdresp);
}

